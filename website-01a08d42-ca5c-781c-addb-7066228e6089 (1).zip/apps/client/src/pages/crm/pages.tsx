import { useState, type ReactNode } from "react";
import { Link, useNavigate } from "react-router-dom";
import {
  ArrowDownRight,
  ArrowUpRight,
  CalendarDays,
  ChevronRight,
  CircleAlert,
  Filter,
  MoreHorizontal,
  Search,
  TrendingUp,
} from "lucide-react";
import {
  Area,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  ComposedChart,
  Legend,
  Line,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { CrmShell, EmptyState, SectionHeader, StatCard, StatusBadge } from "./CrmShell";
import {
  achievementByRep,
  activeDeals,
  attainment,
  attentionItems,
  collectionsByStatus,
  deals,
  formatCurrency,
  formatDate,
  invoices,
  monthlyTrend,
  openPipeline,
  pipelineByStage,
  purchaseOrders,
  stageColors,
  stageOrder,
  targets,
  team,
  totalAchieved,
  totalInvoiced,
  totalTarget,
  collected,
  overdueExposure,
  weightedPipeline,
  winRate,
} from "@/data/crm";

const chartTooltip = {
  contentStyle: { borderRadius: 12, border: "1px solid #e7ebf2", boxShadow: "0 8px 24px rgba(20, 33, 61, 0.08)", fontSize: 12 },
};

function PageFrame({ children }: { children: ReactNode }) {
  return <CrmShell>{children}</CrmShell>;
}

function ChartCard({ title, subtitle, children, className = "" }: { title: string; subtitle: string; children: ReactNode; className?: string }) {
  return (
    <section className={`crm-card ${className}`}>
      <div className="crm-card-heading">
        <div>
          <h2 className="crm-card-title">{title}</h2>
          <p className="crm-card-subtitle">{subtitle}</p>
        </div>
        <button className="crm-more" aria-label={`More options for ${title}`}><MoreHorizontal size={18} /></button>
      </div>
      {children}
    </section>
  );
}

export function DashboardPage() {
  const [period, setPeriod] = useState("YTD");
  const navigate = useNavigate();
  const topAttention = attentionItems;

  return (
    <PageFrame>
      <SectionHeader
        eyebrow="Operating snapshot · Sep 10, 2026"
        title="Good morning, Albear."
        description="A sharper view of target attainment, deal momentum, and cash collection across the MedSales team."
        action={
          <div className="flex items-center gap-2">
            <Select value={period} onValueChange={setPeriod}>
              <SelectTrigger className="crm-select w-[118px]"><CalendarDays size={15} /><SelectValue /></SelectTrigger>
              <SelectContent><SelectItem value="YTD">YTD 2026</SelectItem><SelectItem value="Q3">Q3 2026</SelectItem><SelectItem value="MTD">This month</SelectItem></SelectContent>
            </Select>
            <Button className="crm-primary-button" onClick={() => navigate("/forecast")}>Review pipeline <ArrowUpRight size={15} /></Button>
          </div>
        }
      />

      <div className="crm-stat-grid">
        <StatCard label="Revenue achieved" value={formatCurrency(totalAchieved, true)} helper={`${Math.round(attainment * 100)}% of ${formatCurrency(totalTarget, true)} target`} accent="teal" trend="+12.4%" />
        <StatCard label="Open pipeline" value={formatCurrency(openPipeline, true)} helper={`${activeDeals} active deals with value`} accent="navy" trend="+8.1%" />
        <StatCard label="Weighted forecast" value={formatCurrency(weightedPipeline, true)} helper="Probability-adjusted open value" accent="amber" trend="+5.6%" />
        <StatCard label="Collection exposure" value={formatCurrency(overdueExposure, true)} helper={`${invoices.filter((row) => row.status !== "Paid").length} invoices outside paid status`} accent="rose" trend="-4.2%" />
      </div>

      <div className="crm-dashboard-grid">
        <ChartCard title="Achievement by rep" subtitle="Revenue delivered against target · EUR">
          <div className="crm-chart-wrap">
            <ResponsiveContainer width="100%" height={270}>
              <BarChart data={achievementByRep} margin={{ top: 12, right: 16, left: -12, bottom: 0 }} barGap={8}>
                <CartesianGrid vertical={false} stroke="#edf0f5" />
                <XAxis dataKey="rep" axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: "#8b98aa" }} />
                <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: "#8b98aa" }} tickFormatter={(value: number) => `€${Math.round(value / 1000)}k`} />
                <Tooltip {...chartTooltip} formatter={(value) => formatCurrency(Number(value ?? 0))} />
                <Legend iconType="circle" wrapperStyle={{ fontSize: 11, color: "#6e7c92" }} />
                <Bar name="Target" dataKey="target" fill="#dfe5ee" radius={[5, 5, 0, 0]} />
                <Bar name="Achieved" dataKey="achieved" fill="#2a9d8f" radius={[5, 5, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </ChartCard>

        <ChartCard title="Pipeline by stage" subtitle="Open and weighted value · EUR">
          <div className="crm-chart-wrap">
            <ResponsiveContainer width="100%" height={270}>
              <BarChart data={pipelineByStage.filter((row) => row.amount > 0)} layout="vertical" margin={{ top: 8, right: 18, left: 18, bottom: 0 }}>
                <CartesianGrid horizontal={false} stroke="#edf0f5" />
                <XAxis type="number" axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: "#8b98aa" }} tickFormatter={(value: number) => `€${Math.round(value / 1_000_000)}M`} />
                <YAxis dataKey="stage" type="category" width={82} axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: "#6e7c92" }} />
                <Tooltip {...chartTooltip} formatter={(value) => formatCurrency(Number(value ?? 0))} />
                <Bar dataKey="amount" name="Pipeline" radius={[0, 5, 5, 0]}>
                  {pipelineByStage.filter((row) => row.amount > 0).map((entry) => <Cell key={entry.stage} fill={stageColors[entry.stage]} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </ChartCard>

        <ChartCard title="Collections mix" subtitle={`${formatCurrency(totalInvoiced)} invoiced across four records`}>
          <div className="crm-collection-chart">
            <ResponsiveContainer width="48%" height={210}>
              <PieChart>
                <Pie data={collectionsByStatus} dataKey="amount" nameKey="status" innerRadius={58} outerRadius={82} paddingAngle={4}>
                  {collectionsByStatus.map((entry) => <Cell key={entry.status} fill={{ Paid: "#2a9d8f", Sent: "#5b6b8c", Overdue: "#d86c75", Draft: "#dfe5ee" }[entry.status]} />)}
                </Pie>
                <Tooltip {...chartTooltip} formatter={(value) => formatCurrency(Number(value ?? 0))} />
              </PieChart>
            </ResponsiveContainer>
            <div className="flex-1 space-y-3">
              {collectionsByStatus.map((entry) => (
                <div key={entry.status} className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-2 text-[12px] text-[#6f7d92]"><span className="crm-legend-dot" style={{ backgroundColor: { Paid: "#2a9d8f", Sent: "#5b6b8c", Overdue: "#d86c75", Draft: "#dfe5ee" }[entry.status] }} />{entry.status}</div>
                  <div className="text-right"><div className="text-[12px] font-bold text-[#27354b]">{formatCurrency(entry.amount, true)}</div><div className="text-[10px] text-[#a0abba]">{entry.count} invoice{entry.count > 1 ? "s" : ""}</div></div>
                </div>
              ))}
            </div>
          </div>
        </ChartCard>

        <ChartCard title="Commercial momentum" subtitle="Monthly movement across revenue, pipeline, and collections">
          <div className="crm-chart-wrap">
            <ResponsiveContainer width="100%" height={210}>
              <ComposedChart data={monthlyTrend} margin={{ top: 12, right: 8, left: -12, bottom: 0 }}>
                <defs>
                  <linearGradient id="revenueFill" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#2a9d8f" stopOpacity={0.22} /><stop offset="95%" stopColor="#2a9d8f" stopOpacity={0} /></linearGradient>
                </defs>
                <CartesianGrid vertical={false} stroke="#edf0f5" />
                <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: "#8b98aa" }} />
                <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: "#8b98aa" }} tickFormatter={(value: number) => `€${Math.round(value / 1000)}k`} />
                <Tooltip {...chartTooltip} formatter={(value) => formatCurrency(Number(value ?? 0))} />
                <Area type="monotone" name="Achieved" dataKey="achieved" stroke="#2a9d8f" fill="url(#revenueFill)" strokeWidth={2.5} />
                <Line type="monotone" name="Collected" dataKey="collected" stroke="#f4a261" strokeWidth={2.5} dot={false} />
                <Line type="monotone" name="Pipeline" dataKey="pipeline" stroke="#5b6b8c" strokeWidth={2} dot={false} strokeDasharray="4 5" />
              </ComposedChart>
            </ResponsiveContainer>
          </div>
        </ChartCard>
      </div>

      <section className="crm-card mt-5">
        <div className="crm-card-heading">
          <div><h2 className="crm-card-title">Needs attention</h2><p className="crm-card-subtitle">The three places where a focused follow-up can change the week.</p></div>
          <span className="crm-source-tag">Workbook snapshot</span>
        </div>
        <div className="crm-attention-grid">
          {topAttention.map((item) => (
            <Link to={item.route} key={item.label} className={`crm-attention-item attention-${item.tone}`}>
              <div className="flex items-start justify-between gap-3"><span className="crm-attention-label">{item.label}</span><ChevronRight size={16} /></div>
              <div className="mt-3 text-[18px] font-extrabold tracking-tight text-[#25334a]">{item.value}</div>
              <div className="mt-1 text-[12px] text-[#7e8ca0]">{item.detail}</div>
            </Link>
          ))}
        </div>
      </section>
    </PageFrame>
  );
}

function DataTable({ children }: { children: React.ReactNode }) {
  return <div className="crm-table-wrap"><table className="crm-table">{children}</table></div>;
}

function RouteTableHeader({ title, description, search, setSearch, filter, setFilter, filterOptions, action }: {
  title: string; description: string; search: string; setSearch: (value: string) => void; filter: string; setFilter: (value: string) => void; filterOptions: string[]; action?: ReactNode;
}) {
  return (
    <SectionHeader eyebrow="Operational detail" title={title} description={description} action={action ?? (
      <div className="flex items-center gap-2">
        <div className="crm-inline-search"><Search size={15} /><Input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search..." /></div>
        <Select value={filter} onValueChange={setFilter}><SelectTrigger className="crm-select w-[142px]"><Filter size={14} /><SelectValue /></SelectTrigger><SelectContent>{filterOptions.map((option) => <SelectItem key={option} value={option}>{option}</SelectItem>)}</SelectContent></Select>
      </div>
    )} />
  );
}

export function TargetsPage() {
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("All statuses");
  const rows = targets.filter((row) => row.rep.toLowerCase().includes(search.toLowerCase()) && (filter === "All statuses" || row.status === filter));
  return <PageFrame><RouteTableHeader title="Sales targets" description="Rep-level targets and achievement tracking from the source CRM workbook." search={search} setSearch={setSearch} filter={filter} setFilter={setFilter} filterOptions={["All statuses", "On Track", "At Risk", "Setup"]} action={<Button className="crm-secondary-button"><TrendingUp size={15} /> Export view</Button>} />
    <div className="crm-stat-grid crm-stat-grid-3"><StatCard label="Annual target" value={formatCurrency(totalTarget, true)} helper="Across 12 seats" accent="navy" /><StatCard label="Achieved" value={formatCurrency(totalAchieved, true)} helper={`${Math.round(attainment * 100)}% attainment`} accent="teal" /><StatCard label="Gap to target" value={formatCurrency(totalTarget - totalAchieved, true)} helper="Focus for next review" accent="amber" /></div>
    <section className="crm-card"><DataTable><thead><tr><th>Rep</th><th>Region</th><th>Focus</th><th>Target</th><th>Achieved</th><th>Progress</th><th>Status</th></tr></thead><tbody>{rows.map((row) => { const pct = row.target ? Math.round(row.achieved / row.target * 100) : 0; return <tr key={row.id}><td><div className="font-semibold text-[#2b3a51]">{row.rep}</div><div className="text-[11px] text-[#a0abba]">{row.id}</div></td><td>{row.region}</td><td>{row.focus}</td><td>{formatCurrency(row.target, true)}</td><td>{formatCurrency(row.achieved, true)}</td><td><div className="flex items-center gap-2"><div className="crm-progress"><span style={{ width: `${Math.min(pct, 100)}%` }} /></div><span className="text-[11px] font-semibold text-[#627089]">{pct}%</span></div></td><td><StatusBadge status={row.status} /></td></tr> })}</tbody></DataTable>{rows.length === 0 && <EmptyState title="No target records found" detail="Try a different search or status filter." />}</section>
  </PageFrame>;
}

export function ForecastPage() {
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("All stages");
  const rows = deals.filter((row) => (row.deal + row.client).toLowerCase().includes(search.toLowerCase()) && (filter === "All stages" || row.stage === filter));
  return <PageFrame><RouteTableHeader title="Sales forecast" description="Deals, close timing, weighted value, and next actions in one operating view." search={search} setSearch={setSearch} filter={filter} setFilter={setFilter} filterOptions={["All stages", ...stageOrder]} action={<Button className="crm-primary-button"><ArrowUpRight size={15} /> Add opportunity</Button>} />
    <div className="crm-stat-grid crm-stat-grid-3"><StatCard label="Open pipeline" value={formatCurrency(openPipeline, true)} helper={`${activeDeals} active deals`} accent="navy" /><StatCard label="Weighted pipeline" value={formatCurrency(weightedPipeline, true)} helper="Probability-adjusted" accent="amber" /><StatCard label="Win rate" value={`${Math.round(winRate * 100)}%`} helper="Closed won vs. progressed" accent="teal" /></div>
    <section className="crm-card"><DataTable><thead><tr><th>Deal</th><th>Client</th><th>Stage</th><th>Amount</th><th>Gross profit</th><th>Close date</th><th>Next action</th></tr></thead><tbody>{rows.map((row) => <tr key={row.id}><td><div className="font-semibold text-[#2b3a51]">{row.deal}</div><div className="text-[11px] text-[#a0abba]">{row.id}</div></td><td>{row.client}</td><td><StatusBadge status={row.stage} /></td><td>{formatCurrency(row.amount, true)}</td><td>{formatCurrency(row.amount * row.margin, true)}</td><td>{formatDate(row.closeDate)}</td><td><span className="crm-next-action">{row.nextAction}</span></td></tr>)}</tbody></DataTable></section>
  </PageFrame>;
}

export function PurchaseOrdersPage() {
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("All statuses");
  const rows = purchaseOrders.filter((row) => (row.client + row.rep).toLowerCase().includes(search.toLowerCase()) && (filter === "All statuses" || row.status === filter));
  return <PageFrame><RouteTableHeader title="Purchase orders" description="Track orders from approval to delivery, with a clear owner and follow-up cue." search={search} setSearch={setSearch} filter={filter} setFilter={setFilter} filterOptions={["All statuses", "Pending", "Approved", "Shipped", "Delivered"]} action={<Button className="crm-secondary-button"><ShoppingCartIcon /> New PO</Button>} />
    <section className="crm-card"><DataTable><thead><tr><th>PO</th><th>Client</th><th>Owner</th><th>Amount</th><th>Status</th><th>Order date</th><th>Delivery date</th><th>Follow-up</th></tr></thead><tbody>{rows.map((row) => <tr key={row.id}><td className="font-semibold text-[#2b3a51]">{row.id}</td><td>{row.client}</td><td>{row.rep}</td><td>{formatCurrency(row.amount, true)}</td><td><StatusBadge status={row.status} /></td><td>{formatDate(row.orderDate)}</td><td>{formatDate(row.deliveryDate)}</td><td>{row.followUp}</td></tr>)}</tbody></DataTable></section>
  </PageFrame>;
}

function ShoppingCartIcon() { return <ArrowUpRight size={15} />; }

export function InvoicesPage() {
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("All statuses");
  const rows = invoices.filter((row) => (row.client + row.id).toLowerCase().includes(search.toLowerCase()) && (filter === "All statuses" || row.status === filter));
  return <PageFrame><RouteTableHeader title="Invoices & collections" description="See what has been issued, what has been collected, and where cash is at risk." search={search} setSearch={setSearch} filter={filter} setFilter={setFilter} filterOptions={["All statuses", "Paid", "Sent", "Overdue", "Draft"]} action={<Button className="crm-primary-button"><ReceiptIcon /> Create invoice</Button>} />
    <div className="crm-stat-grid crm-stat-grid-3"><StatCard label="Invoiced" value={formatCurrency(totalInvoiced, true)} helper={`${invoices.length} invoices`} accent="navy" /><StatCard label="Collected" value={formatCurrency(collected, true)} helper={`${Math.round(collected / totalInvoiced * 100)}% collected`} accent="teal" /><StatCard label="At risk" value={formatCurrency(overdueExposure, true)} helper="Sent + overdue exposure" accent="rose" /></div>
    <section className="crm-card"><DataTable><thead><tr><th>Invoice</th><th>Client</th><th>PO</th><th>Amount</th><th>Status</th><th>Due date</th><th>Days overdue</th><th>Follow-up</th></tr></thead><tbody>{rows.map((row) => <tr key={row.id}><td className="font-semibold text-[#2b3a51]">{row.id}</td><td>{row.client}</td><td>{row.po}</td><td>{formatCurrency(row.amount, true)}</td><td><StatusBadge status={row.status} /></td><td>{formatDate(row.dueDate)}</td><td>{row.daysOverdue > 0 ? <span className="text-[#c55a66] font-semibold">{row.daysOverdue} days</span> : "—"}</td><td>{row.followUp}</td></tr>)}</tbody></DataTable></section>
  </PageFrame>;
}

function ReceiptIcon() { return <ArrowUpRight size={15} />; }

export function PipelinesPage() {
  return <PageFrame><SectionHeader eyebrow="Analysis" title="Pipeline analysis" description="A manager-ready view of stage health, coverage, and where opportunities are getting stuck." action={<Button className="crm-secondary-button"><TrendingUp size={15} /> Share summary</Button>} />
    <div className="crm-stat-grid crm-stat-grid-4"><StatCard label="Open pipeline" value={formatCurrency(openPipeline, true)} helper="Excludes closed deals" accent="navy" /><StatCard label="Weighted pipeline" value={formatCurrency(weightedPipeline, true)} helper="Probability-adjusted" accent="amber" /><StatCard label="Active deals" value={`${activeDeals}`} helper="With positive amount" accent="teal" /><StatCard label="Win rate" value={`${Math.round(winRate * 100)}%`} helper="Progressed opportunities" accent="rose" /></div>
    <div className="crm-dashboard-grid"><ChartCard title="Stage volume" subtitle="Count and open value by stage"><div className="crm-chart-wrap"><ResponsiveContainer width="100%" height={300}><BarChart data={pipelineByStage} margin={{ top: 8, right: 12, left: -10, bottom: 0 }}><CartesianGrid vertical={false} stroke="#edf0f5" /><XAxis dataKey="stage" axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: "#8b98aa" }} /><YAxis yAxisId="amount" axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: "#8b98aa" }} tickFormatter={(value: number) => `€${Math.round(value / 1_000_000)}M`} /><YAxis yAxisId="count" orientation="right" axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: "#8b98aa" }} /><Tooltip {...chartTooltip} formatter={(value, name) => name === "amount" ? formatCurrency(Number(value ?? 0)) : Number(value ?? 0)} /><Bar yAxisId="amount" dataKey="amount" fill="#2a9d8f" radius={[6, 6, 0, 0]} /><Line yAxisId="count" type="monotone" dataKey="count" stroke="#f4a261" strokeWidth={2.5} /></BarChart></ResponsiveContainer></div></ChartCard>
      <ChartCard title="Weighted coverage" subtitle="The share of each stage that survives probability weighting"><div className="crm-stage-list">{pipelineByStage.map((row) => <div key={row.stage} className="crm-stage-row"><div className="flex items-center gap-3"><span className="crm-stage-dot" style={{ backgroundColor: stageColors[row.stage] }} /><div><div className="text-[12px] font-semibold text-[#34425a]">{row.stage}</div><div className="text-[11px] text-[#98a4b5]">{row.count} deal{row.count === 1 ? "" : "s"}</div></div></div><div className="text-right"><div className="text-[12px] font-bold text-[#2d3b52]">{formatCurrency(row.weighted, true)}</div><div className="text-[11px] text-[#8a98ad]">{row.amount ? Math.round(row.weighted / row.amount * 100) : 0}% weighted</div></div></div>)}</div></ChartCard></div>
    <section className="crm-card mt-5"><div className="crm-card-heading"><div><h2 className="crm-card-title">Pipeline hygiene</h2><p className="crm-card-subtitle">Signals worth discussing in the next commercial review.</p></div></div><div className="crm-insight-grid"><div className="crm-insight"><CircleAlert size={18} className="text-[#d86c75]" /><div><div className="font-semibold text-[#34425a]">Two high-value opportunities need a next step</div><p>City General and Metro Clinic are both past their original close dates.</p></div></div><div className="crm-insight"><ArrowDownRight size={18} className="text-[#f4a261]" /><div><div className="font-semibold text-[#34425a]">Prospecting is carrying the most volume</div><p>Three records are still unassigned, which makes coverage look larger than it is.</p></div></div></div></section>
  </PageFrame>;
}

export function SalesTeamPage() {
  const [search, setSearch] = useState("");
  const rows = team.filter((row) => (row.rep + row.focus).toLowerCase().includes(search.toLowerCase()));
  return <PageFrame><SectionHeader eyebrow="People" title="Sales team" description="Manage the 12-seat roster and keep setup placeholders visible until the team is fully staffed." action={<div className="crm-inline-search"><Search size={15} /><Input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search team..." /></div>} />
    <section className="crm-card"><DataTable><thead><tr><th>Rep</th><th>Region</th><th>Focus area</th><th>Contact</th><th>Status</th><th /></tr></thead><tbody>{rows.map((row) => <tr key={row.id}><td><div className="flex items-center gap-3"><div className="crm-table-avatar">{row.rep.split(" ").map((part) => part[0]).join("").slice(0, 2)}</div><div><div className="font-semibold text-[#2b3a51]">{row.rep}</div><div className="text-[11px] text-[#a0abba]">{row.id}</div></div></div></td><td>{row.region}</td><td>{row.focus}</td><td><div>{row.email ?? "—"}</div><div className="text-[11px] text-[#a0abba]">{row.phone ?? "—"}</div></td><td><StatusBadge status={row.status} /></td><td><button className="crm-more" aria-label={`More actions for ${row.rep}`}><MoreHorizontal size={17} /></button></td></tr>)}</tbody></DataTable></section>
  </PageFrame>;
}

export function SetupPage() {
  return <PageFrame><SectionHeader eyebrow="Governance" title="Lists & setup" description="Visible lookup values and provenance notes carried over from the source workbook." />
    <div className="crm-setup-grid">{[
      ["Pipeline stages", ["Prospecting", "Cold", "Warm", "Closed Won", "Closed Lost"]],
      ["PO statuses", ["Pending", "Approved", "Shipped", "Delivered", "Cancelled"]],
      ["Invoice statuses", ["Draft", "Sent", "Overdue", "Paid"]],
      ["Team statuses", ["Active", "Setup"]],
    ].map(([label, values]) => <section className="crm-card" key={label as string}><div className="crm-card-heading"><div><h2 className="crm-card-title">{label as string}</h2><p className="crm-card-subtitle">Source lookup list</p></div></div><div className="flex flex-wrap gap-2">{(values as string[]).map((value) => <StatusBadge key={value} status={value} />)}</div></section>)}</div>
    <section className="crm-card mt-5"><div className="crm-card-heading"><div><h2 className="crm-card-title">Workbook notes</h2><p className="crm-card-subtitle">What this web console is carrying forward from Excel.</p></div></div><div className="crm-note-list"><div>Sample values in the target, forecast, PO, and invoice rows are adapted from the attached MedSales concept.</div><div>Seven setup placeholders are included to bring the team to 12 seats.</div><div>Formula-driven values are represented as live client-side metrics for this read-only web snapshot.</div><div>Last updated in source workbook: September 3, 2026.</div></div></section>
  </PageFrame>;
}
